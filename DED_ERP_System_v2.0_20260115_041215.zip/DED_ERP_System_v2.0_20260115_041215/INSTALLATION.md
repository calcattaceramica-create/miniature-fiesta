# دليل التثبيت التفصيلي

هذا الدليل يشرح خطوات تثبيت نظام إدارة المخزون المتكامل بالتفصيل.

---

## المتطلبات الأساسية

### 1. Python
- **الإصدار المطلوب:** Python 3.8 أو أحدث
- **التحقق من التثبيت:**
  ```bash
  python --version
  # أو
  python3 --version
  ```

### 2. pip
- يأتي مع Python افتراضياً
- **التحقق:**
  ```bash
  pip --version
  ```

### 3. Git (اختياري)
- لاستنساخ المشروع من GitHub
- **التحميل:** [git-scm.com](https://git-scm.com/)

---

## التثبيت على Windows

### الطريقة 1: استخدام start.bat (الأسهل)

1. **تحميل المشروع**
   - حمّل ملف ZIP من GitHub
   - أو استنسخ باستخدام Git:
     ```cmd
     git clone <repository-url>
     cd DED
     ```

2. **تشغيل الملف التلقائي**
   ```cmd
   start.bat
   ```
   
   هذا الملف سيقوم بـ:
   - إنشاء البيئة الافتراضية
   - تثبيت المتطلبات
   - تهيئة قاعدة البيانات
   - تشغيل التطبيق

3. **فتح المتصفح**
   - افتح: `http://localhost:5000`
   - اسم المستخدم: `admin`
   - كلمة المرور: `admin123`

### الطريقة 2: التثبيت اليدوي

1. **فتح Command Prompt**
   - اضغط `Win + R`
   - اكتب `cmd` واضغط Enter

2. **الانتقال لمجلد المشروع**
   ```cmd
   cd C:\Users\YourName\DED
   ```

3. **إنشاء البيئة الافتراضية**
   ```cmd
   python -m venv venv
   ```

4. **تفعيل البيئة الافتراضية**
   ```cmd
   venv\Scripts\activate
   ```
   
   ستلاحظ `(venv)` في بداية السطر

5. **تثبيت المتطلبات**
   ```cmd
   pip install -r requirements.txt
   ```

6. **إعداد ملف البيئة**
   ```cmd
   copy .env.example .env
   ```

7. **تهيئة قاعدة البيانات**
   ```cmd
   flask init-db
   ```

8. **تشغيل التطبيق**
   ```cmd
   python run.py
   ```

---

## التثبيت على Linux/Mac

### الطريقة 1: استخدام start.sh (الأسهل)

1. **تحميل المشروع**
   ```bash
   git clone <repository-url>
   cd DED
   ```

2. **إعطاء صلاحيات التنفيذ**
   ```bash
   chmod +x start.sh
   ```

3. **تشغيل الملف**
   ```bash
   ./start.sh
   ```

### الطريقة 2: التثبيت اليدوي

1. **تثبيت Python (إذا لم يكن مثبتاً)**
   
   **Ubuntu/Debian:**
   ```bash
   sudo apt update
   sudo apt install python3 python3-pip python3-venv
   ```
   
   **macOS (باستخدام Homebrew):**
   ```bash
   brew install python3
   ```

2. **استنساخ المشروع**
   ```bash
   git clone <repository-url>
   cd DED
   ```

3. **إنشاء البيئة الافتراضية**
   ```bash
   python3 -m venv venv
   ```

4. **تفعيل البيئة الافتراضية**
   ```bash
   source venv/bin/activate
   ```

5. **تثبيت المتطلبات**
   ```bash
   pip install -r requirements.txt
   ```

6. **إعداد ملف البيئة**
   ```bash
   cp .env.example .env
   ```

7. **تهيئة قاعدة البيانات**
   ```bash
   flask init-db
   ```

8. **تشغيل التطبيق**
   ```bash
   python run.py
   ```

---

## التثبيت باستخدام Docker

### المتطلبات
- Docker Desktop (Windows/Mac)
- Docker و Docker Compose (Linux)

### الخطوات

1. **تثبيت Docker**
   - **Windows/Mac:** حمّل [Docker Desktop](https://www.docker.com/products/docker-desktop)
   - **Linux:**
     ```bash
     sudo apt install docker.io docker-compose
     ```

2. **استنساخ المشروع**
   ```bash
   git clone <repository-url>
   cd DED
   ```

3. **بناء وتشغيل الحاويات**
   ```bash
   docker-compose up -d
   ```

4. **التحقق من الحالة**
   ```bash
   docker-compose ps
   ```

5. **فتح المتصفح**
   - افتح: `http://localhost:5000`

6. **إيقاف الحاويات**
   ```bash
   docker-compose down
   ```

---

## استكشاف الأخطاء الشائعة

### خطأ: "python is not recognized"

**الحل:**
- تأكد من تثبيت Python
- أضف Python إلى PATH
- أعد تشغيل Command Prompt

### خطأ: "pip is not recognized"

**الحل:**
```bash
python -m pip install --upgrade pip
```

### خطأ: "Permission denied"

**Linux/Mac:**
```bash
sudo chmod +x start.sh
```

### خطأ: "Port 5000 already in use"

**الحل:**
- أوقف التطبيق الذي يستخدم المنفذ 5000
- أو غيّر المنفذ في `run.py`:
  ```python
  app.run(host='0.0.0.0', port=5001, debug=True)
  ```

### خطأ: "Database locked"

**الحل:**
```bash
# احذف قاعدة البيانات وأعد إنشائها
rm erp_system.db
flask init-db
```

---

## التحقق من التثبيت

### 1. اختبار الاتصال
```bash
curl http://localhost:5000
```

### 2. التحقق من قاعدة البيانات
```bash
# يجب أن يكون الملف موجوداً
ls -la erp_system.db
```

### 3. التحقق من المتطلبات
```bash
pip list
```

---

## الخطوات التالية

بعد التثبيت الناجح:

1. **غيّر كلمة المرور**
   - سجّل دخول بـ `admin` / `admin123`
   - اذهب إلى الإعدادات > الملف الشخصي
   - غيّر كلمة المرور

2. **أدخل بيانات الشركة**
   - الإعدادات > بيانات الشركة
   - أدخل معلومات شركتك

3. **أنشئ المستخدمين**
   - الإعدادات > المستخدمين
   - أضف مستخدمين جدد

4. **ابدأ بإدخال البيانات**
   - التصنيفات
   - المنتجات
   - العملاء
   - الموردين

---

## تحديث النظام

### من Git
```bash
git pull origin main
pip install -r requirements.txt
flask db upgrade  # إذا كانت هناك تحديثات على قاعدة البيانات
```

### يدوياً
1. حمّل الإصدار الجديد
2. انسخ ملف `erp_system.db` (احتفظ بنسخة احتياطية)
3. استبدل الملفات
4. شغّل `pip install -r requirements.txt`

---

## إلغاء التثبيت

### حذف البيئة الافتراضية
```bash
# Windows
rmdir /s venv

# Linux/Mac
rm -rf venv
```

### حذف قاعدة البيانات
```bash
rm erp_system.db
```

### حذف المشروع بالكامل
```bash
cd ..
rm -rf DED
```

---

## الدعم

إذا واجهت أي مشاكل:

1. راجع [QUICKSTART.md](QUICKSTART.md)
2. راجع [README.md](README.md)
3. افتح Issue في GitHub
4. راسلنا على: support@erpsystem.com

---

**نتمنى لك تجربة ممتعة! 🚀**

