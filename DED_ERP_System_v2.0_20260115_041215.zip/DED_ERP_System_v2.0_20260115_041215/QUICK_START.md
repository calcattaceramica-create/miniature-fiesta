# 🚀 تعليمات التشغيل السريع

## 1. التثبيت

```bash
# تثبيت المتطلبات
pip install -r requirements.txt

# تهيئة قاعدة البيانات
python run.py init-db

# إنشاء مستخدم مدير
python run.py create-admin
```

## 2. التشغيل

```bash
# تشغيل السيرفر
python run.py

# أو
flask run
```

## 3. الوصول للنظام

افتح المتصفح على: http://localhost:5000

- اسم المستخدم: admin
- كلمة المرور: (التي أدخلتها عند الإنشاء)

## 4. الميزات الجديدة

✅ تكامل نقطة البيع مع فواتير المبيعات
✅ إنشاء فاتورة تلقائياً عند إتمام البيع
✅ ربط كامل بين POS والمحاسبة

للمزيد من التفاصيل، راجع:
- START_HERE.md
- POS_INVOICE_INTEGRATION.md
- USER_GUIDE.md
