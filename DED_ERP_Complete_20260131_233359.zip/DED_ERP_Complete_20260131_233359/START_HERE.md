# DED ERP System - Complete Package
# نظام DED ERP - الحزمة الكاملة

**Export Date:** 2026-01-31 23:33:59

## 🎯 What's Included

This package contains:
- ✅ Complete DED ERP System
- ✅ Multi-Tenant License Management
- ✅ Ready for Render Deployment
- ✅ Complete Documentation
- ✅ Default Production License

## 🚀 Quick Start

### Option 1: Deploy to Render (Recommended)

1. **Extract this package**
2. **Read `RENDER_DEPLOYMENT.md`**
3. **Push to GitHub**
4. **Deploy on Render**

### Option 2: Run Locally

```bash
pip install -r requirements.txt
python initialize_master_database.py
python run.py
```

## 📚 Documentation

- `RENDER_DEPLOYMENT.md` - Complete deployment guide
- `EXPORT_README.md` - Package contents and features
- `README.md` - Application documentation

## 🔑 Default License

```
License Key: RENDER-2026-PROD-LIVE
Username: admin
Password: admin123
Type: Lifetime
```

## 📊 License Management

Access at: `/security/licenses`

Features:
- Create new licenses
- Manage existing licenses
- Suspend/Activate licenses
- Multi-tenant isolation

## 🆘 Support

For help, check the documentation files or contact support.

---

**DED ERP System** - Professional Business Management
