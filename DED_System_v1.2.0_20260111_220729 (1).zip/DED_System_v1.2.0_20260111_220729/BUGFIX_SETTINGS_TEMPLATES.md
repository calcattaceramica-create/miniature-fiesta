# إصلاح صفحات الإعدادات

## المشكلة

عند محاولة الوصول إلى صفحات الإعدادات، ظهرت الأخطاء التالية:

```
jinja2.exceptions.TemplateNotFound: settings/company.html
jinja2.exceptions.TemplateNotFound: settings/branches.html
```

## السبب

ملفات القوالب التالية كانت **مفقودة**:
- ❌ `app/templates/settings/company.html`
- ❌ `app/templates/settings/branches.html`

على الرغم من وجود:
- ✅ المسارات (Routes) في `app/settings/routes.py`
- ✅ نماذج Company و Branch في `app/models.py`
- ✅ ملفات قوالب أخرى في `app/templates/settings/`

## الحل

تم إنشاء الملفات المفقودة وإضافة المسارات اللازمة.

---

## 1. صفحة بيانات الشركة (company.html)

### الملف المنشأ
✅ `app/templates/settings/company.html` (289 سطر)

### المميزات

#### أ. نموذج تحديث البيانات
- اسم الشركة (عربي + إنجليزي)
- الرقم الضريبي
- السجل التجاري
- معلومات الاتصال (هاتف، بريد، موقع)
- العنوان والمدينة والدولة
- العملة (9 عملات مختلفة)
- نسبة الضريبة
- رفع شعار الشركة

#### ب. بطاقة معلومات الشركة
- عرض الشعار
- عرض جميع البيانات
- تاريخ الإنشاء

#### ج. إحصائيات سريعة
- عدد الفروع
- نسبة الضريبة
- العملة المستخدمة

#### د. نموذج إنشاء شركة جديدة
- يظهر عند عدم وجود بيانات شركة
- نموذج منبثق (Modal)

### المسارات المضافة

```python
# عرض صفحة الشركة
@bp.route('/company')
def company()

# تحديث بيانات الشركة
@bp.route('/company/update', methods=['POST'])
def update_company()

# إنشاء بيانات شركة جديدة
@bp.route('/company/create', methods=['POST'])
def create_company()
```

### العملات المدعومة
1. ريال سعودي (SAR) - افتراضي
2. دولار أمريكي (USD)
3. يورو (EUR)
4. درهم إماراتي (AED)
5. دينار كويتي (KWD)
6. دينار بحريني (BHD)
7. ريال عماني (OMR)
8. ريال قطري (QAR)
9. جنيه مصري (EGP)

---

## 2. صفحة إدارة الفروع (branches.html)

### الملف المنشأ
✅ `app/templates/settings/branches.html` (303 سطر)

### المميزات

#### أ. عرض الفروع (Grid Layout)
- بطاقات للفروع (3 في الصف)
- عرض جميع معلومات الفرع
- أزرار تعديل وحذف
- تمييز الفروع غير النشطة

#### ب. معلومات كل فرع
- الاسم (عربي + إنجليزي)
- الكود
- العنوان
- المدينة
- الهاتف
- المدير
- الحالة (نشط/غير نشط)
- تاريخ الإنشاء

#### ج. نموذج إضافة فرع
- نموذج منبثق (Modal)
- جميع الحقول المطلوبة
- اختيار المدير من قائمة المستخدمين
- تفعيل/تعطيل الفرع

#### د. نموذج تعديل فرع
- نموذج منبثق (Modal)
- تعبئة البيانات الحالية تلقائياً
- تحديث جميع الحقول

#### هـ. نموذج حذف فرع
- تأكيد الحذف
- تحذير من حذف البيانات المرتبطة

### المسارات المضافة

```python
# عرض صفحة الفروع
@bp.route('/branches')
def branches()

# إضافة فرع جديد
@bp.route('/branches/add', methods=['POST'])
def add_branch()

# تعديل فرع
@bp.route('/branches/edit/<int:id>', methods=['POST'])
def edit_branch(id)

# حذف فرع
@bp.route('/branches/delete/<int:id>', methods=['POST'])
def delete_branch(id)
```

### JavaScript Functions
```javascript
editBranch(id, name, name_en, code, address, city, phone, manager_id, is_active)
deleteBranch(id, name)
```

---

## الملفات المعدلة/المنشأة

### ملفات جديدة
1. ✅ `app/templates/settings/company.html` (289 سطر)
2. ✅ `app/templates/settings/branches.html` (303 سطر)

### ملفات معدلة
3. ✅ `app/settings/routes.py` - إضافة 5 مسارات جديدة

---

## الاختبار

### 1. اختبار تحميل القوالب
```bash
python -c "from app import create_app; app = create_app(); app.jinja_env.get_template('settings/company.html'); print('✅ OK')"
python -c "from app import create_app; app = create_app(); app.jinja_env.get_template('settings/branches.html'); print('✅ OK')"
```

**النتيجة**: ✅ نجح

### 2. اختبار المسارات
```bash
python -c "from app import create_app; from flask import url_for; app = create_app(); ctx = app.test_request_context(); ctx.push(); print(url_for('settings.company')); print(url_for('settings.branches'))"
```

**النتيجة**: 
- `/settings/company` ✅
- `/settings/branches` ✅

---

## الروابط

بعد تشغيل `python run.py`:

### صفحات الإعدادات
- 🏢 [بيانات الشركة](http://localhost:5000/settings/company)
- 🌳 [إدارة الفروع](http://localhost:5000/settings/branches)
- 👥 [إدارة المستخدمين](http://localhost:5000/settings/users)
- 🎭 [إدارة الأدوار](http://localhost:5000/settings/roles)
- 🔑 [الصلاحيات](http://localhost:5000/settings/permissions)
- 👤 [الملف الشخصي](http://localhost:5000/settings/profile)

---

## الحالة

✅ **تم الحل** - جميع صفحات الإعدادات تعمل بشكل كامل

---

**تاريخ الإصلاح**: 2026-01-11  
**الملفات المنشأة**: 2 ملف (592 سطر)  
**المسارات المضافة**: 5 مسارات  
**الحالة**: ✅ جاهز للاستخدام

