# ✅ قاعدة البيانات والنماذج - دليل شامل

## 🎯 نظرة عامة

تم إعداد قاعدة البيانات والنماذج بشكل كامل للنظام.

---

## 📁 الملفات المتوفرة

### 1. ملفات النماذج (Models)

```
app/
├── models.py                  ✅ النماذج الأساسية
├── models_inventory.py        ✅ نماذج المخزون
├── models_sales.py           ✅ نماذج المبيعات
├── models_purchases.py       ✅ نماذج المشتريات
├── models_accounting.py      ✅ نماذج المحاسبة
├── models_hr.py              ✅ نماذج الموارد البشرية
└── models_pos.py             ✅ نماذج نقاط البيع
```

### 2. ملفات الإعداد

```
├── config.py                 ✅ إعدادات قاعدة البيانات
├── init_db.py               ✅ تهيئة قاعدة البيانات
└── seed_data.py             ✅ بيانات تجريبية
```

### 3. ملفات التوثيق

```
├── DATABASE.md              ✅ توثيق قاعدة البيانات
├── DATABASE_SCHEMA.md       ✅ مخطط قاعدة البيانات
├── DATABASE_SETUP.md        ✅ دليل الإعداد
├── MODELS.md                ✅ توثيق النماذج
└── MIGRATION.md             ✅ دليل الترحيل
```

---

## 🗄️ الجداول المتوفرة

### Master Data (البيانات الأساسية)
- ✅ users - المستخدمون
- ✅ roles - الأدوار
- ✅ permissions - الصلاحيات
- ✅ companies - الشركات
- ✅ branches - الفروع
- ✅ currencies - العملات

### Inventory (المخزون)
- ✅ categories - التصنيفات
- ✅ units - وحدات القياس
- ✅ products - المنتجات
- ✅ warehouses - المستودعات
- ✅ stock - المخزون
- ✅ stock_movements - حركات المخزون

### Sales (المبيعات)
- ✅ customers - العملاء
- ✅ sales_invoices - فواتير البيع
- ✅ sales_invoice_items - تفاصيل الفواتير
- ✅ quotations - عروض الأسعار
- ✅ sales_orders - طلبات البيع
- ✅ sales_returns - مرتجعات البيع

### Purchases (المشتريات)
- ✅ suppliers - الموردون
- ✅ purchase_orders - طلبات الشراء
- ✅ purchase_invoices - فواتير الشراء
- ✅ purchase_invoice_items - تفاصيل الفواتير
- ✅ purchase_returns - مرتجعات الشراء

### Accounting (المحاسبة)
- ✅ accounts - دليل الحسابات
- ✅ journal_entries - القيود اليومية
- ✅ journal_entry_items - سطور القيود
- ✅ payments - المدفوعات
- ✅ bank_accounts - الحسابات البنكية
- ✅ cost_centers - مراكز التكلفة

### HR (الموارد البشرية)
- ✅ employees - الموظفون
- ✅ departments - الأقسام
- ✅ positions - الوظائف
- ✅ attendance - الحضور
- ✅ leaves - الإجازات
- ✅ payroll - الرواتب

### POS (نقاط البيع)
- ✅ pos_sessions - الورديات
- ✅ pos_orders - الطلبات
- ✅ pos_order_items - تفاصيل الطلبات

---

## 🚀 البدء السريع

### 1. تهيئة قاعدة البيانات

```bash
python init_db.py
```

**النتيجة:**
- ✅ إنشاء جميع الجداول
- ✅ إدخال البيانات الافتراضية
- ✅ إنشاء مستخدم admin
- ✅ إنشاء الأدوار الأساسية
- ✅ إنشاء العملات
- ✅ إنشاء وحدات القياس
- ✅ إنشاء التصنيفات
- ✅ إنشاء دليل الحسابات

### 2. إضافة بيانات تجريبية

```bash
python seed_data.py
```

**النتيجة:**
- ✅ إضافة منتجات تجريبية
- ✅ إضافة عملاء تجريبيين
- ✅ إضافة موردين تجريبيين
- ✅ إضافة مخزون أولي

### 3. بيانات الدخول

```
Username: admin
Password: admin123
```

⚠️ **مهم:** غيّر كلمة المرور فوراً!

---

## 📊 إحصائيات قاعدة البيانات

### عدد الجداول
- **إجمالي الجداول:** 40+ جدول
- **النماذج الرئيسية:** 35 نموذج
- **الجداول المساعدة:** 5+ جداول

### البيانات الافتراضية
- **المستخدمون:** 1 (admin)
- **الأدوار:** 3 (admin, manager, user)
- **العملات:** 4 (SAR, USD, EUR, EGP)
- **وحدات القياس:** 6 وحدات
- **التصنيفات:** 5 تصنيفات
- **الحسابات:** 19 حساب

### البيانات التجريبية (بعد seed_data.py)
- **المنتجات:** 6 منتجات
- **العملاء:** 3 عملاء
- **الموردون:** 2 موردين

---

## 🔗 العلاقات

### One-to-Many
- Company → Branches (1:N)
- Branch → Users (1:N)
- Category → Products (1:N)
- Warehouse → Stock (1:N)
- Customer → Sales Invoices (1:N)
- Supplier → Purchase Invoices (1:N)
- Invoice → Invoice Items (1:N)

### Many-to-Many
- Roles ↔ Permissions (N:M)

### Self-Referential
- Category → Category (parent/child)
- Account → Account (parent/child)

---

## 🔐 الأمان

### تشفير كلمات المرور
- ✅ استخدام Werkzeug لتشفير كلمات المرور
- ✅ لا يتم تخزين كلمات المرور بشكل نصي

### القيود
- ✅ Primary Keys على جميع الجداول
- ✅ Foreign Keys للحفاظ على سلامة البيانات
- ✅ UNIQUE Constraints على الأكواد
- ✅ NOT NULL على الحقول الإلزامية

### الفهارس
- ✅ فهارس على المفاتيح الأساسية
- ✅ فهارس على المفاتيح الأجنبية
- ✅ فهارس على حقول البحث

---

## 📝 الاستخدام

### إنشاء مستخدم جديد

```python
from app import create_app, db
from app.models import User

app = create_app()
with app.app_context():
    user = User(
        username='john',
        email='john@example.com',
        full_name='John Doe'
    )
    user.set_password('password123')
    db.session.add(user)
    db.session.commit()
```

### إنشاء منتج جديد

```python
from app.models_inventory import Product

product = Product(
    name='منتج جديد',
    code='PROD-007',
    barcode='1234567890007',
    category_id=1,
    unit_id=1,
    cost_price=100.00,
    selling_price=150.00
)
db.session.add(product)
db.session.commit()
```

### إنشاء فاتورة بيع

```python
from app.models_sales import SalesInvoice, SalesInvoiceItem

invoice = SalesInvoice(
    invoice_number='INV-001',
    customer_id=1,
    warehouse_id=1
)
db.session.add(invoice)
db.session.commit()

item = SalesInvoiceItem(
    invoice_id=invoice.id,
    product_id=1,
    quantity=2,
    unit_price=150.00
)
db.session.add(item)
db.session.commit()
```

---

## 🔍 التحقق

### التحقق من الجداول

```bash
python -c "from app import create_app, db; app = create_app(); app.app_context().push(); print(db.engine.table_names())"
```

### التحقق من البيانات

```bash
python -c "from app import create_app, db; from app.models import User; app = create_app(); app.app_context().push(); print(f'Users: {User.query.count()}')"
```

---

## 📚 المراجع

- [DATABASE.md](DATABASE.md) - توثيق قاعدة البيانات
- [DATABASE_SCHEMA.md](DATABASE_SCHEMA.md) - مخطط قاعدة البيانات
- [DATABASE_SETUP.md](DATABASE_SETUP.md) - دليل الإعداد
- [MODELS.md](MODELS.md) - توثيق النماذج
- [MIGRATION.md](MIGRATION.md) - دليل الترحيل

---

## ✅ الحالة

- ✅ **النماذج:** جاهزة 100%
- ✅ **قاعدة البيانات:** جاهزة 100%
- ✅ **البيانات الافتراضية:** جاهزة 100%
- ✅ **التوثيق:** جاهز 100%

---

**آخر تحديث:** 2026-01-10  
**الحالة:** ✅ جاهز للاستخدام

