# DED ERP System - Render Deployment Guide
دليل نشر نظام DED ERP على Render

## 🚀 Quick Start

### 1. Push to GitHub
```bash
git init
git add .
git commit -m "Initial commit for Render deployment"
git remote add origin YOUR_GITHUB_REPO_URL
git push -u origin main
```

### 2. Deploy on Render
1. Go to https://render.com
2. Click "New +" → "Blueprint"
3. Connect your GitHub repository
4. Render will automatically detect `render.yaml`
5. Click "Apply" to deploy

### 3. Access Your Application
- Your app will be available at: `https://ded-inventory-system.onrender.com`
- Default credentials:
  - License Key: `RENDER-2026-PROD-LIVE`
  - Username: `admin`
  - Password: `admin123`

## 📋 What's Included

- ✅ Complete Flask application
- ✅ Multi-tenant license system
- ✅ SQLite database (no PostgreSQL needed)
- ✅ Automatic database initialization
- ✅ Production-ready configuration

## 🔧 Configuration

All configuration is in `render.yaml`:
- Python 3.11.7
- Gunicorn with 2 workers
- Frankfurt region (free tier)
- Automatic builds on push

## 📝 Notes

- Free tier includes 750 hours/month
- App sleeps after 15 minutes of inactivity
- First request after sleep takes ~30 seconds
- Database persists across deployments

## 🆘 Support

For issues or questions, check the logs in Render dashboard.

---
Created: 2026-01-31 23:30:58
