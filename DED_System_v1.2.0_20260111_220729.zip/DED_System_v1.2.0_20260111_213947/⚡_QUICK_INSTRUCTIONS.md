# ⚡ تعليمات سريعة - 5 دقائق

<div align="center">

## 🚀 ابدأ الآن في 3 خطوات!

</div>

---

## الخطوة 1: التثبيت (دقيقة واحدة)

### Windows - الطريقة السهلة ⭐
```batch
# انقر مرتين على الملف
setup.bat
```

### يدوياً (جميع الأنظمة)
```bash
python -m venv venv
venv\Scripts\activate  # Windows
source venv/bin/activate  # Linux/Mac
pip install -r requirements.txt
python init_db.py
python seed_data.py
python seed_crm_data.py
```

---

## الخطوة 2: التشغيل (30 ثانية)

### Windows
```batch
# انقر مرتين على الملف
start.bat
```

### يدوياً
```bash
venv\Scripts\activate  # Windows
source venv/bin/activate  # Linux/Mac
python run.py
```

---

## الخطوة 3: الاستخدام (3 دقائق)

### 1. افتح المتصفح
```
http://127.0.0.1:5000
```

### 2. سجل الدخول
- **اسم المستخدم:** `admin`
- **كلمة المرور:** `admin123`

### 3. استكشف الأنظمة
- 👥 **HR** - إدارة الموظفين
- 💼 **CRM** - إدارة العملاء
- 📦 **المخزون** - إدارة المنتجات
- 💰 **المبيعات** - الفواتير
- 📊 **التقارير** - الإحصائيات

---

## 🎯 الأنظمة المتوفرة

| النظام | الرابط | الوصف |
|--------|--------|-------|
| HR | `/hr/dashboard` | إدارة الموظفين والحضور والإجازات |
| CRM | `/crm/dashboard` | إدارة العملاء والفرص والمبيعات |
| المخزون | `/inventory/products` | إدارة المنتجات والمستودعات |
| المبيعات | `/sales/invoices` | فواتير البيع والعملاء |
| المشتريات | `/purchases/invoices` | فواتير الشراء والموردين |
| المحاسبة | `/accounting/dashboard` | القيود والحسابات |
| POS | `/pos/` | نقاط البيع |
| التقارير | `/reports/` | التقارير والإحصائيات |

---

## 📚 الوثائق

### للبدء
- 📖 [QUICK_START.md](QUICK_START.md) - دليل شامل
- 🚀 [START_APPLICATION.md](START_APPLICATION.md) - دليل التشغيل

### للتصدير
- 📦 [EXPORT_GUIDE.md](EXPORT_GUIDE.md) - دليل التصدير
- ✅ [EXPORT_COMPLETE.md](EXPORT_COMPLETE.md) - تأكيد الاكتمال

### للمطورين
- 📊 [PROJECT_INFO.md](PROJECT_INFO.md) - معلومات تقنية
- 📚 [INDEX.md](INDEX.md) - فهرس الوثائق

---

## ❓ مشاكل شائعة

### المشكلة: "No module named 'flask'"
```bash
# الحل: تأكد من تفعيل البيئة الافتراضية
venv\Scripts\activate
pip install -r requirements.txt
```

### المشكلة: "Address already in use"
```bash
# الحل: استخدم منفذ آخر
python run.py --port 5001
```

### المشكلة: "Database not found"
```bash
# الحل: أنشئ قاعدة البيانات
python init_db.py
```

---

## 🔐 بيانات الدخول

### حساب المدير
- اسم المستخدم: `admin`
- كلمة المرور: `admin123`
- الصلاحيات: كاملة

### حساب موظف
- اسم المستخدم: `user1`
- كلمة المرور: `user123`
- الصلاحيات: محدودة

⚠️ **مهم:** غيّر كلمات المرور فوراً!

---

## 📦 التصدير

### Git (موصى به)
```bash
git init
git add .
git commit -m "DED System v1.2.0"
git remote add origin <your-repo>
git push -u origin main
```

### ZIP
```
1. احذف: venv/, __pycache__/, instance/
2. اضغط المجلد
3. شارك الملف
```

---

## 📞 الدعم

- 📖 راجع [FAQ.md](FAQ.md)
- 🐛 افتح Issue على GitHub
- 📧 راسلنا: support@dedsystem.com

---

## ✅ قائمة التحقق

- [ ] Python 3.8+ مثبت
- [ ] البيئة الافتراضية منشأة
- [ ] المتطلبات مثبتة
- [ ] قاعدة البيانات منشأة
- [ ] البيانات التجريبية منشأة
- [ ] التطبيق يعمل
- [ ] تم تسجيل الدخول

---

<div align="center">

## 🎉 جاهز!

**استمتع باستخدام نظام DED!**

**الإصدار:** 1.2.0 | **التاريخ:** 2026-01-11

[⬆ العودة للأعلى](#-تعليمات-سريعة---5-دقائق)

</div>

