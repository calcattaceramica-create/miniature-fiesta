"""Create requirements.txt file"""

requirements = """Flask==3.1.2
Flask-SQLAlchemy==3.1.1
Flask-Login==0.6.3
Flask-WTF==1.2.2
Flask-Migrate==4.1.0
Flask-Babel==4.0.0
WTForms==3.2.1
email-validator==2.3.0
python-dotenv==1.2.1
alembic==1.18.0
SQLAlchemy==2.0.45
Werkzeug==3.1.5
Jinja2==3.1.6
MarkupSafe==3.0.3
itsdangerous==2.2.0
click==8.3.1
blinker==1.9.0
greenlet==3.3.0
Mako==1.3.10
Babel==2.17.0
pytz==2025.2
dnspython==2.8.0
idna==3.11
typing_extensions==4.15.0
colorama==0.4.6
"""

with open('requirements.txt', 'w', encoding='utf-8') as f:
    f.write(requirements.strip())

print("✅ requirements.txt created successfully!")

