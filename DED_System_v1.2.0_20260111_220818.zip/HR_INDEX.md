# 📚 فهرس نظام إدارة الموارد البشرية

## 🎯 ابدأ من هنا

### للمستخدمين الجدد:
1. **[دليل البدء السريع](HR_QUICK_START.md)** ⭐ - ابدأ هنا!
2. **[دليل المستخدم](HR_SYSTEM_README.md)** - دليل شامل
3. **[الملخص النهائي](HR_FINAL_SUMMARY.md)** - نظرة عامة

### للمطورين:
1. **[ملخص المشروع](HR_SYSTEM_COMPLETE.md)** - تفاصيل تقنية
2. **[Models](app/models_hr.py)** - نماذج قاعدة البيانات
3. **[Routes](app/hr/routes.py)** - المسارات والوظائف

---

## 📁 هيكل الملفات

### Backend (الخلفية)
```
app/
├── models_hr.py          # نماذج قاعدة البيانات
└── hr/
    ├── __init__.py       # Blueprint
    └── routes.py         # المسارات والوظائف
```

### Frontend (الواجهة)
```
app/templates/hr/
├── dashboard.html                      # لوحة التحكم
├── employees.html                      # قائمة الموظفين
├── add_employee.html                   # إضافة موظف
├── edit_employee.html                  # تعديل موظف
├── employee_details.html               # تفاصيل الموظف
├── departments.html                    # الأقسام
├── positions.html                      # المناصب
├── attendance.html                     # سجلات الحضور
├── add_attendance.html                 # تسجيل حضور
├── leaves.html                         # طلبات الإجازات
├── add_leave.html                      # طلب إجازة
├── leave_types.html                    # أنواع الإجازات
├── payroll.html                        # كشوف الرواتب
├── generate_payroll.html               # إنشاء كشف رواتب
├── payroll_details.html                # تفاصيل الراتب
├── reports.html                        # صفحة التقارير
└── attendance_summary_report.html      # تقرير ملخص الحضور
```

### Documentation (التوثيق)
```
HR_INDEX.md                 # هذا الملف
HR_QUICK_START.md          # دليل البدء السريع
HR_SYSTEM_README.md        # دليل المستخدم
HR_SYSTEM_COMPLETE.md      # ملخص المشروع
HR_FINAL_SUMMARY.md        # الملخص النهائي
```

### Utilities (المساعدات)
```
seed_hr_data.py            # إضافة بيانات تجريبية
requirements.txt           # المتطلبات
```

---

## 🔗 الروابط السريعة

### الصفحات الرئيسية:
- **لوحة التحكم**: `http://localhost:5000/hr/dashboard`
- **الموظفين**: `http://localhost:5000/hr/employees`
- **الحضور**: `http://localhost:5000/hr/attendance`
- **الإجازات**: `http://localhost:5000/hr/leaves`
- **الرواتب**: `http://localhost:5000/hr/payroll`
- **التقارير**: `http://localhost:5000/hr/reports`

### الإعدادات:
- **الأقسام**: `http://localhost:5000/hr/departments`
- **المناصب**: `http://localhost:5000/hr/positions`
- **أنواع الإجازات**: `http://localhost:5000/hr/leave_types`

---

## 🎯 الوظائف الرئيسية

### 1. إدارة الموظفين
- إضافة/تعديل/حذف الموظفين
- عرض تفاصيل الموظف
- البحث والفلترة

### 2. إدارة الحضور
- تسجيل حضور/انصراف
- حساب ساعات العمل
- تتبع التأخير والساعات الإضافية

### 3. إدارة الإجازات
- طلب إجازة
- الموافقة/رفض الطلبات
- تتبع رصيد الإجازات

### 4. إدارة الرواتب
- إنشاء كشوف رواتب
- حساب البدلات والخصومات
- اعتماد ودفع الرواتب

### 5. التقارير
- تقرير الحضور
- تقرير الإجازات
- تقرير الرواتب

---

## 🚀 التشغيل السريع

```bash
# 1. تثبيت المتطلبات
pip install -r requirements.txt

# 2. إنشاء قاعدة البيانات
python init_db.py

# 3. إضافة بيانات تجريبية
python seed_hr_data.py

# 4. تشغيل التطبيق
python run.py
```

---

## 📊 قاعدة البيانات

### الجداول:
1. **employees** - الموظفين
2. **departments** - الأقسام
3. **positions** - المناصب
4. **attendance** - الحضور
5. **leaves** - الإجازات
6. **leave_types** - أنواع الإجازات
7. **payroll** - الرواتب

---

## 🎨 التصميم

- Bootstrap 5
- Font Awesome Icons
- Responsive Design
- RTL Support
- Modern UI/UX

---

## 📝 ملاحظات

- جميع الصفحات تدعم اللغة العربية
- التقارير قابلة للطباعة
- النظام يدعم Soft Delete
- حساب تلقائي للساعات والرواتب

---

## 🆘 المساعدة

### للمشاكل الشائعة:
راجع قسم "حل المشاكل" في [دليل البدء السريع](HR_QUICK_START.md)

### للاستفسارات:
راجع [دليل المستخدم](HR_SYSTEM_README.md)

---

## ✅ قائمة التحقق

قبل البدء:
- [ ] تثبيت Python 3.8+
- [ ] تثبيت المتطلبات
- [ ] إنشاء قاعدة البيانات
- [ ] إضافة بيانات تجريبية
- [ ] تشغيل التطبيق

---

**ابدأ الآن من [دليل البدء السريع](HR_QUICK_START.md)! 🚀**

