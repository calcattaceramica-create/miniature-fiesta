# 🔧 حل المشاكل الشائعة

## ✅ التطبيق يعمل الآن!

إذا رأيت هذه الرسالة في Terminal:
```
 * Running on http://127.0.0.1:5000
```

**معناها: التطبيق يعمل بنجاح! ✅**

---

## 🌐 كيف تصل إلى التطبيق؟

### افتح المتصفح على أحد هذه الروابط:

1. **http://127.0.0.1:5000** ⭐ (موصى به)
2. **http://localhost:5000**
3. **http://192.168.217.169:5000** (من أجهزة أخرى في نفس الشبكة)

---

## 🔐 بيانات الدخول

- **اسم المستخدم:** `admin`
- **كلمة المرور:** `admin123`

---

## ❌ المشاكل الشائعة وحلولها

### المشكلة 1: "التطبيق لا يعمل"

**الأعراض:**
- لا يظهر شيء عند تشغيل `python run.py`
- رسالة خطأ

**الحلول:**

#### الحل 1: تأكد من تفعيل البيئة الافتراضية
```bash
# Windows
venv\Scripts\activate

# Linux/Mac
source venv/bin/activate

# ثم شغل التطبيق
python run.py
```

#### الحل 2: أعد تثبيت المتطلبات
```bash
pip install -r requirements.txt
```

#### الحل 3: أعد إنشاء قاعدة البيانات
```bash
python init_db.py
python seed_data.py
python seed_crm_data.py
```

---

### المشكلة 2: "Address already in use"

**المعنى:** المنفذ 5000 مستخدم بالفعل

**الحل 1:** أوقف التطبيق القديم
```bash
# اضغط Ctrl + C في Terminal
```

**الحل 2:** استخدم منفذ آخر
```bash
# عدّل ملف run.py
# غيّر السطر الأخير إلى:
app.run(debug=True, port=5001)
```

**الحل 3:** أوقف جميع عمليات Python
```bash
# Windows
taskkill /F /IM python.exe

# Linux/Mac
pkill -f python
```

---

### المشكلة 3: "No module named 'flask'"

**المعنى:** Flask غير مثبت

**الحل:**
```bash
# تأكد من تفعيل البيئة الافتراضية
venv\Scripts\activate

# ثبت المتطلبات
pip install -r requirements.txt
```

---

### المشكلة 4: "Database not found"

**المعنى:** قاعدة البيانات غير موجودة

**الحل:**
```bash
python init_db.py
python seed_data.py
python seed_crm_data.py
```

---

### المشكلة 5: "الصفحة لا تفتح في المتصفح"

**الأعراض:**
- التطبيق يعمل في Terminal
- لكن المتصفح يقول "Can't reach this page"

**الحلول:**

#### الحل 1: تأكد من الرابط
```
استخدم: http://127.0.0.1:5000
وليس: https://127.0.0.1:5000 (بدون s)
```

#### الحل 2: جرب متصفح آخر
- جرب Chrome
- جرب Firefox
- جرب Edge

#### الحل 3: تأكد من التطبيق يعمل
```bash
# في Terminal يجب أن ترى:
 * Running on http://127.0.0.1:5000
```

---

### المشكلة 6: "خطأ في تسجيل الدخول"

**الأعراض:**
- "Invalid username or password"

**الحل:**

#### تأكد من البيانات الصحيحة:
- اسم المستخدم: `admin` (بأحرف صغيرة)
- كلمة المرور: `admin123`

#### إذا لم تعمل، أعد إنشاء قاعدة البيانات:
```bash
# احذف قاعدة البيانات القديمة
del instance\erp_system.db  # Windows
rm instance/erp_system.db   # Linux/Mac

# أنشئ قاعدة بيانات جديدة
python init_db.py
python seed_data.py
```

---

## 🚀 التشغيل السريع

### الطريقة 1: استخدام start.bat (Windows)
```batch
# انقر مرتين على الملف
start.bat
```

### الطريقة 2: يدوياً
```bash
# 1. تفعيل البيئة
venv\Scripts\activate

# 2. تشغيل التطبيق
python run.py

# 3. فتح المتصفح
# افتح: http://127.0.0.1:5000
```

---

## 🛑 إيقاف التطبيق

### في Terminal:
```
اضغط: Ctrl + C
```

### إذا لم يتوقف:
```bash
# Windows
taskkill /F /IM python.exe

# Linux/Mac
pkill -f "python run.py"
```

---

## 📊 التحقق من حالة التطبيق

### علامات التشغيل الناجح:
```
✅  * Serving Flask app 'app'
✅  * Debug mode: on
✅  * Running on http://127.0.0.1:5000
```

### علامات وجود مشكلة:
```
❌ ModuleNotFoundError
❌ Address already in use
❌ Database error
❌ ImportError
```

---

## 🔍 فحص الأخطاء

### إذا ظهرت أخطاء:

1. **اقرأ رسالة الخطأ بعناية**
2. **ابحث عن الخطأ في هذا الملف**
3. **جرب الحلول المقترحة**
4. **إذا لم تحل المشكلة، راجع FAQ.md**

---

## 📞 الدعم

### إذا لم تحل المشكلة:

1. ✅ راجع [FAQ.md](FAQ.md)
2. ✅ راجع [QUICK_START.md](QUICK_START.md)
3. ✅ راجع [START_APPLICATION.md](START_APPLICATION.md)
4. ✅ افتح Issue على GitHub
5. ✅ راسلنا: support@dedsystem.com

---

## ✅ قائمة التحقق

قبل طلب المساعدة، تأكد من:

- [ ] Python 3.8+ مثبت
- [ ] البيئة الافتراضية منشأة
- [ ] البيئة الافتراضية مفعّلة
- [ ] المتطلبات مثبتة (pip install -r requirements.txt)
- [ ] قاعدة البيانات منشأة (python init_db.py)
- [ ] المنفذ 5000 متاح
- [ ] جربت الرابط الصحيح (http://127.0.0.1:5000)

---

<div align="center">

## 🎉 التطبيق يعمل الآن!

**افتح المتصفح على:**  
**http://127.0.0.1:5000**

**سجل الدخول:**  
Username: `admin`  
Password: `admin123`

---

**استمتع باستخدام نظام DED!**

</div>

