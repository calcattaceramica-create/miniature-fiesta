# معلومات المشروع (Project Information)

## 📊 نظرة عامة

**اسم المشروع:** نظام إدارة الموارد البشرية وإدارة علاقات العملاء  
**الاسم بالإنجليزية:** DED HR & CRM System  
**الإصدار:** 1.2.0  
**تاريخ الإصدار:** 2026-01-11  
**الحالة:** ✅ جاهز للإنتاج  

---

## 🎯 الهدف من المشروع

نظام متكامل يجمع بين إدارة الموارد البشرية (HR) وإدارة علاقات العملاء (CRM) في منصة واحدة، مصمم خصيصاً للشركات الصغيرة والمتوسطة في المنطقة العربية.

---

## 📈 الإحصائيات

### عدد الملفات والأسطر

```
إجمالي ملفات Python: ~50 ملف
إجمالي أسطر الكود: ~15,000 سطر
عدد النماذج (Models): 25+ نموذج
عدد المسارات (Routes): 100+ مسار
عدد القوالب (Templates): 80+ قالب HTML
```

### الوحدات الرئيسية

| الوحدة | الملفات | الوظائف |
|--------|---------|----------|
| HR System | 15+ | إدارة الموظفين، الحضور، الإجازات، الرواتب |
| CRM System | 10+ | العملاء المحتملين، الفرص، المهام، الحملات |
| Inventory | 8+ | إدارة المخزون والمستودعات |
| Sales | 6+ | المبيعات والفواتير |
| Accounting | 8+ | المحاسبة والقيود |
| POS | 5+ | نقاط البيع |
| Reports | 6+ | التقارير والإحصائيات |

---

## 🏗️ البنية المعمارية

### النمط المعماري
- **MVC (Model-View-Controller)**
- **Blueprint-based Architecture**
- **Modular Design**

### طبقات التطبيق

```
┌─────────────────────────────────┐
│     Presentation Layer          │
│  (Templates, Forms, Static)     │
├─────────────────────────────────┤
│     Application Layer           │
│    (Routes, Controllers)        │
├─────────────────────────────────┤
│      Business Layer             │
│   (Models, Business Logic)      │
├─────────────────────────────────┤
│       Data Layer                │
│  (SQLAlchemy, Database)         │
└─────────────────────────────────┘
```

---

## 🔧 التقنيات المستخدمة

### Backend
- **Framework:** Flask 3.1.2
- **ORM:** SQLAlchemy 2.0.45
- **Database:** SQLite (قابل للترقية لـ PostgreSQL/MySQL)
- **Authentication:** Flask-Login 0.6.3
- **Forms:** Flask-WTF 1.2.2, WTForms 3.2.1
- **Migrations:** Flask-Migrate 4.1.0
- **i18n:** Flask-Babel 4.0.0

### Frontend
- **CSS Framework:** Bootstrap 5.3
- **Icons:** Font Awesome 6 + Bootstrap Icons
- **JavaScript:** Vanilla JS + jQuery
- **Charts:** Chart.js (للتقارير)

### Security
- **Password Hashing:** Werkzeug Security
- **CSRF Protection:** Flask-WTF
- **Session Management:** Flask-Login
- **Input Validation:** WTForms Validators

---

## 📦 الوحدات والميزات

### 1. نظام الموارد البشرية (HR)

#### الموظفين
- ✅ إدارة كاملة للموظفين
- ✅ معلومات شخصية ووظيفية
- ✅ الصور الشخصية
- ✅ المستندات والملفات

#### الحضور والانصراف
- ✅ تسجيل الحضور والانصراف
- ✅ حساب ساعات العمل
- ✅ تقارير الحضور
- ✅ التأخير والغياب

#### الإجازات
- ✅ طلب إجازة
- ✅ الموافقة/الرفض
- ✅ أنواع متعددة
- ✅ رصيد الإجازات

#### الرواتب
- ✅ الراتب الأساسي
- ✅ البدلات والمكافآت
- ✅ الخصومات
- ✅ كشوف الرواتب

#### العقود
- ✅ محددة/غير محددة المدة
- ✅ تتبع التواريخ
- ✅ حالة العقد

#### التقييم والتدريب
- ✅ تقييم الأداء
- ✅ الدورات التدريبية
- ✅ التسجيل في الدورات

### 2. نظام CRM

#### العملاء المحتملين (Leads)
- ✅ إدارة العملاء المحتملين
- ✅ تتبع الحالة
- ✅ التحويل إلى فرص
- ✅ مصادر متعددة

#### الفرص (Opportunities)
- ✅ إدارة الفرص البيعية
- ✅ مراحل البيع
- ✅ القيمة المتوقعة
- ✅ احتمالية النجاح

#### التفاعلات
- ✅ تسجيل التفاعلات
- ✅ أنواع متعددة
- ✅ الربط بالعملاء والفرص

#### المهام
- ✅ إنشاء وتعيين المهام
- ✅ الأولويات
- ✅ تواريخ الاستحقاق
- ✅ تتبع الحالة

#### الحملات
- ✅ إدارة الحملات التسويقية
- ✅ تتبع الميزانية
- ✅ قياس النتائج
- ✅ معدل التحويل

---

## 📊 قاعدة البيانات

### النماذج الرئيسية

#### HR Models (models.py)
- User
- Employee
- Department
- Branch
- Attendance
- Leave
- Salary
- Contract
- Performance
- Training

#### CRM Models (models_crm.py)
- Lead
- Opportunity
- Interaction
- Task
- Campaign

#### Other Models
- Product (Inventory)
- Customer (Sales)
- Invoice (Sales)
- Account (Accounting)
- Transaction (Accounting)

### العلاقات
- One-to-Many: Employee → Attendance, Leave, Salary
- Many-to-One: Employee → Department, Branch
- Many-to-Many: Employee ↔ Training
- One-to-Many: Lead → Opportunity
- Many-to-One: Task → User

---

## 🔐 الأمان

### المصادقة
- ✅ تسجيل الدخول الآمن
- ✅ تشفير كلمات المرور (Werkzeug)
- ✅ إدارة الجلسات (Flask-Login)
- ✅ تذكرني (Remember Me)

### الحماية
- ✅ CSRF Protection
- ✅ XSS Prevention
- ✅ SQL Injection Prevention (SQLAlchemy)
- ✅ Input Validation

### الصلاحيات
- ✅ نظام الأدوار (Admin, Manager, Employee)
- ✅ التحكم في الوصول
- ✅ صلاحيات مخصصة

---

## 📱 واجهة المستخدم

### التصميم
- ✅ متجاوب (Responsive)
- ✅ دعم RTL كامل
- ✅ ألوان متناسقة
- ✅ أيقونات واضحة

### التجربة
- ✅ سهولة الاستخدام
- ✅ تنقل سلس
- ✅ رسائل واضحة
- ✅ تأكيدات للعمليات الحساسة

---

## 📈 الأداء

### التحسينات
- ✅ استعلامات محسّنة
- ✅ Lazy Loading
- ✅ Caching (قيد التطوير)
- ✅ Pagination

### قابلية التوسع
- ✅ بنية معيارية
- ✅ قابل للتوسع
- ✅ سهل الصيانة

---

## 🧪 الاختبار

### أنواع الاختبارات
- Unit Tests (قيد التطوير)
- Integration Tests (قيد التطوير)
- Manual Testing ✅

---

## 📚 التوثيق

### الملفات المتوفرة
- ✅ README.md - الوثائق الرئيسية
- ✅ QUICK_START.md - دليل البدء السريع
- ✅ DEPLOYMENT.md - دليل النشر
- ✅ EXPORT_GUIDE.md - دليل التصدير
- ✅ CHANGELOG.md - سجل التغييرات
- ✅ PROJECT_INFO.md - هذا الملف

---

## 🚀 خارطة الطريق

### الإصدار 1.3 (قريباً)
- [ ] نظام الإشعارات
- [ ] تصدير التقارير PDF/Excel
- [ ] تكامل البريد الإلكتروني
- [ ] الأرشفة الإلكترونية

### الإصدار 2.0 (المستقبل)
- [ ] تطبيق موبايل
- [ ] API RESTful
- [ ] المصادقة الثنائية
- [ ] تكامل WhatsApp
- [ ] الفواتير الإلكترونية

---

## 👥 الفريق

**المطور:** Augment Agent  
**التاريخ:** 2026-01-11  
**الترخيص:** MIT License  

---

## 📞 الاتصال والدعم

- **GitHub:** [Repository URL]
- **Issues:** [Issues URL]
- **Documentation:** README.md

---

**آخر تحديث:** 2026-01-11  
**الإصدار:** 1.2.0

